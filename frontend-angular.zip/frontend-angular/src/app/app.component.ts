import { Component, OnInit } from '@angular/core';
import { ProductoService, PageResponse } from './services/producto.service';
import { Producto } from './models/producto.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Gestion de Productos';

  // Auth
  isAuthenticated = false;
  isAdmin = false;
  loginUsername = '';
  loginPassword = '';
  loginError = '';
  storedUsername = '';

  // Products
  productos: Producto[] = [];
  currentPage = 0;
  totalPages = 0;
  totalElements = 0;
  pageSize = 10;

  // Search
  searchTerm = '';
  searchInput = '';

  // Edit / Create form
  showForm = false;
  editingId: number | null = null;
  formData: Producto = {
    id: 0,
    nombre: '',
    descripcion: '',
    precio: 0,
    stock: 0,
    activo: true
  };
  formError = '';

  constructor(private productoService: ProductoService) {}

  ngOnInit(): void {
    this.checkSession();
  }

  checkSession(): void {
    const credentials = sessionStorage.getItem('credentials');
    const username = sessionStorage.getItem('username');
    const role = sessionStorage.getItem('role');
    if (credentials && username) {
      this.isAuthenticated = true;
      this.storedUsername = username;
      this.isAdmin = role === 'ADMIN';
      this.loadProductos();
    }
  }

  login(): void {
    this.loginError = '';
    this.productoService.verifyCredentials(this.loginUsername, this.loginPassword).subscribe({
      next: (response: any) => {
        const credentials = btoa(this.loginUsername + ':' + this.loginPassword);
        sessionStorage.setItem('credentials', credentials);
        sessionStorage.setItem('username', this.loginUsername);

        let role = 'USER';
        if (response && response.role) {
          role = response.role;
        } else if (response && typeof response === 'string') {
          const upper = response.toUpperCase();
          if (upper.includes('ADMIN')) {
            role = 'ADMIN';
          }
        }
        sessionStorage.setItem('role', role);

        this.isAuthenticated = true;
        this.storedUsername = this.loginUsername;
        this.isAdmin = role === 'ADMIN';
        this.loginUsername = '';
        this.loginPassword = '';
        this.loadProductos();
      },
      error: (err) => {
        this.loginError = 'Credenciales incorrectas. Intente de nuevo.';
      }
    });
  }

  logout(): void {
    sessionStorage.clear();
    this.isAuthenticated = false;
    this.isAdmin = false;
    this.storedUsername = '';
    this.productos = [];
    this.currentPage = 0;
    this.totalPages = 0;
  }

  loadProductos(): void {
    this.productoService.getProductosPaginado(this.currentPage, this.pageSize, this.searchTerm).subscribe({
      next: (response: PageResponse) => {
        this.productos = response.content;
        this.totalPages = response.totalPages;
        this.totalElements = response.totalElements;
        this.currentPage = response.number;
      },
      error: (err) => {
        console.error('Error loading products', err);
        if (err.status === 401 || err.status === 403) {
          this.logout();
        }
      }
    });
  }

  search(): void {
    this.searchTerm = this.searchInput;
    this.currentPage = 0;
    this.loadProductos();
  }

  clearSearch(): void {
    this.searchInput = '';
    this.searchTerm = '';
    this.currentPage = 0;
    this.loadProductos();
  }

  previousPage(): void {
    if (this.currentPage > 0) {
      this.currentPage--;
      this.loadProductos();
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages - 1) {
      this.currentPage++;
      this.loadProductos();
    }
  }

  openCreateForm(): void {
    this.editingId = null;
    this.formData = {
      id: 0,
      nombre: '',
      descripcion: '',
      precio: 0,
      stock: 0,
      activo: true,
      categoriaId: 1,
      imagenUrl: null
    };
    this.formError = '';
    this.showForm = true;
  }

  openEditForm(producto: Producto): void {
    this.editingId = producto.id;
    this.formData = { ...producto };
    this.formError = '';
    this.showForm = true;
  }

  cancelForm(): void {
    this.showForm = false;
    this.editingId = null;
    this.formError = '';
  }

  saveProducto(): void {
    if (!this.formData.nombre || this.formData.nombre.trim() === '') {
      this.formError = 'El nombre es obligatorio.';
      return;
    }
    if (this.formData.precio < 0) {
      this.formError = 'El precio no puede ser negativo.';
      return;
    }
    if (this.formData.stock < 0) {
      this.formError = 'El stock no puede ser negativo.';
      return;
    }

    if (this.editingId !== null) {
      this.productoService.updateProducto(this.editingId, this.formData).subscribe({
        next: () => {
          this.showForm = false;
          this.editingId = null;
          this.loadProductos();
        },
        error: (err) => {
          this.formError = 'Error al actualizar el producto.';
          if (err.status === 401 || err.status === 403) {
            this.logout();
          }
        }
      });
    } else {
      this.productoService.createProducto(this.formData).subscribe({
        next: () => {
          this.showForm = false;
          this.editingId = null;
          this.loadProductos();
        },
        error: (err) => {
          this.formError = 'Error al crear el producto.';
          if (err.status === 401 || err.status === 403) {
            this.logout();
          }
        }
      });
    }
  }

  deleteProducto(producto: Producto): void {
    if (confirm(`¿Está seguro de eliminar "${producto.nombre}"?`)) {
      this.productoService.deleteProducto(producto.id).subscribe({
        next: () => {
          this.loadProductos();
        },
        error: (err) => {
          alert('Error al eliminar el producto.');
          if (err.status === 401 || err.status === 403) {
            this.logout();
          }
        }
      });
    }
  }
}
