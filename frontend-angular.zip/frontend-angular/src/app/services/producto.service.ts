import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Producto } from '../models/producto.model';
import { environment } from '../../environments/environment';

export interface PageResponse {
  content: Producto[];
  totalElements: number;
  totalPages: number;
  number: number;
  size: number;
}

@Injectable({
  providedIn: 'root'
})
export class ProductoService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  private getAuthHeaders(): HttpHeaders {
    const credentials = sessionStorage.getItem('credentials');
    if (credentials) {
      return new HttpHeaders({
        'Authorization': 'Basic ' + credentials,
        'Content-Type': 'application/json'
      });
    }
    return new HttpHeaders({
      'Content-Type': 'application/json'
    });
  }

  getProductosPaginado(page: number, size: number, nombre?: string): Observable<PageResponse> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('size', size.toString());
    if (nombre && nombre.trim() !== '') {
      params = params.set('nombre', nombre.trim());
    }
    return this.http.get<PageResponse>(`${this.apiUrl}/api/productos/paginado`, {
      headers: this.getAuthHeaders(),
      params: params
    });
  }

  getAllProductos(): Observable<Producto[]> {
    return this.http.get<Producto[]>(`${this.apiUrl}/api/productos`, {
      headers: this.getAuthHeaders()
    });
  }

  getProductoById(id: number): Observable<Producto> {
    return this.http.get<Producto>(`${this.apiUrl}/api/productos/${id}`, {
      headers: this.getAuthHeaders()
    });
  }

  createProducto(producto: Producto): Observable<Producto> {
    return this.http.post<Producto>(`${this.apiUrl}/api/productos`, producto, {
      headers: this.getAuthHeaders()
    });
  }

  updateProducto(id: number, producto: Producto): Observable<Producto> {
    return this.http.put<Producto>(`${this.apiUrl}/api/productos/${id}`, producto, {
      headers: this.getAuthHeaders()
    });
  }

  deleteProducto(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/api/productos/${id}`, {
      headers: this.getAuthHeaders()
    });
  }

  verifyCredentials(username: string, password: string): Observable<any> {
    const credentials = btoa(username + ':' + password);
    const headers = new HttpHeaders({
      'Authorization': 'Basic ' + credentials
    });
    return this.http.get(`${this.apiUrl}/api/auth/me`, { headers });
  }

  register(username: string, password: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/api/auth/register`, {
      username: username,
      password: password
    });
  }
}
